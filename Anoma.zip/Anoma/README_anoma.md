# AnomaData: Automated Anomaly Detection for Predictive Maintenance

The goal of this “Anomaly Detection in Predictive Maintenance” series is to be able to predict a breakdown episode without any previous examples.
The proposed framework could be outlined using the following components:
•
In the first place, we define a transformation of the instances, from time-stamps to intervals, with an aggregation that provides a wider view of the event of an anomaly through the inclusion of a parameter for the length of the window that precedes each annotated event.

•
Then, we describe what are the options for the aggregation and what are the implications, including an earliness-aware aggregation derived from the Numenta Anomaly Benchmark (NAB).

•
The next component is the Preceding Window ROC (pw-ROC), that generalise the definition of the classic ROC curve to include the previously mentioned window length parameter. The aggregation of these pw-ROC shapes the ROC surface, as the parameter of the length of the preceding window represents the third dimension.



Many different industries need predictive maintenance solutions to reduce risks and gain actionable insights through processing data from their equipment. Predictive maintenance evaluates the condition of equipment by performing online monitoring. The goal is to perform maintenance before the equipment degrades or breaks down. This Capstone project aims to predict machine breakdowns by identifying anomalies in the data.

## Dataset
The dataset contains approximately 18,000+ rows collected over a few days. The column `y` contains binary labels, with `1` denoting an anomaly. The rest of the columns are predictors.

## Project Steps

### 1. Exploratory Data Analysis (EDA)
- Analyze and understand the data to identify patterns, relationships, and trends.
- Use descriptive statistics and visualizations.

### 2. Data Cleaning
- Standardize the data.
- Handle missing values and outliers.

### 3. Feature Engineering
- Create new features or transform existing features for better model performance.

### 4. Model Selection
- Choose the most appropriate model for the project.

### 5. Model Training
- Split the data into train and test sets.
- Use the train set to estimate the best model parameters.

### 6. Model Validation
- Evaluate the model's performance on data not used during training.
- Ensure the model can generalize to new, unseen data and identify any issues like overfitting.

### 7. Model Deployment
- Deploy the model for real-time anomaly detection.

## Getting Started

### Prerequisites
- Python 3.x
- Libraries: pandas, numpy, scikit-learn, matplotlib, seaborn

### Installation
1. Clone the repository:
    ```bash
    git clone https://github.com/shekhargodse/AnomaData.git
    ```
2. Navigate to the project directory:
    ```bash
    cd AnomaData
    ```
3. Install the required libraries:
    ```bash
    pip install -r requirements.txt
    ```

## Usage
1. Run the exploratory data analysis script:
    ```bash
    python eda.py
    ```
2. Clean the data:
    ```bash
    python data_cleaning.py
    ```
3. Perform feature engineering:
    ```bash
    python feature_engineering.py
    ```
4. Train the model:
    ```bash
    python model_training.py
    ```
5. Validate the model:
    ```bash
    python model_validation.py
    ```
6. Deploy the model:
    ```bash
    python model_deployment.py
    ```

## Contributing
Contributions are welcome! Please fork the repository and submit a pull request.

## License
This project is licensed under the MIT License.

## Acknowledgments
- Thanks to the data science community for their valuable resources and tutorials.

## Documentation

[Documentation](https://linktodocumentation)


## Installation

Install my-project with npm

```bash
  npm install my-project
  cd my-project
```
    
## Deployment

To deploy this project run

```bash
  npm run deploy
```


## Features

- Light/dark mode toggle
- Live previews
- Fullscreen mode
- Cross platform


## Running Tests

To run tests, run the following command

```bash
  npm run test
```

