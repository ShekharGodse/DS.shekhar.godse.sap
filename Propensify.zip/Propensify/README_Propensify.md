
# Propensify (Propensity Model to identify how likely certain target groups customers respond to the marketing campaign)
Propensity modeling is a set of approaches to building predictive models to forecast behavior of a target audience by analyzing their past behaviors. That is to say, propensity models help identify the likelihood of someone performing a certain action. These actions may range from accepting a personalized offer or making a purchase to signing up for a newsletter or churning, etc.
For companies to be good with predictions, propensity models have to be dynamic, scalable, and adaptive. Let’s go through these characteristics in more detail.

Dynamic means models should be built in a way to advance with trends, adapt, and learn on new data as it becomes available.
Scalable means they shouldn’t be created for a single-use scenario but in a way to produce a wide array of predictions.
Adaptive means models should have a proper data pipeline for regular data ingestion, validation, and deployment to timely adjust to changes.


## Data Sources
The dataset for this project comprises categorized as ‘train’, ‘test’.
train.csv Historical data set used for training the model.
test.csv List of potential customers to whom marketing efforts will be directed. The goal is to predict whether to market to these customers (yes/no).
## Data Preprocessing
The next step is to make sure the data selected for propensity modeling is consistent, accurate, and complete. There is an array of data preparation steps you can take to make that happen. In one of our articles, we cover the main techniques to prepare datasets for machine learning, so you can check it out for better understanding.
To effectively estimate propensity scores and draw a full picture of who your customers are, you may consider the following metrics:

demographic information (age, gender, religion, education, etc.);
engagement information (webpage dwell time, the number of emails opened/clicked, web app or mobile app searches, etc.);
transaction and user behavior information (the number of purchases made, the type of products/services purchased, or the time between an offer and conversion, etc.); and
psychographic information (personality characteristics, opinions, likes, and dislikes).
## Model Training and Evaluation
When data is ready, it’s time to build and train propensity models using different algorithmic approaches. ML specialists can choose from an array of machine learning model types including logistic regression, decision trees, random forests, neural networks, and others.

Logistic regression is an algorithm for classifying binary values (1 or 0), e.g., buy/won’t buy. It is used in the prevailing majority of cases for estimating propensity scores.
## Predictions with higher accuracy
Propensity modeling is a powerful tool in the hands of companies that want to make an educated guess on their customers' next moves. But the reality is that the accuracy of predictions is only as high as the quality of built models.

While there are quite a few pre-trained machine learning solutions for calculating various propensity scores, they are often limited in functionality and have their drawbacks. Predictions they make won’t be as accurate as anticipated. This can be attributed to the fact that most off-the-shelf solutions have a small number of basic features, usually accounting for limited data. Of course, for small businesses that don’t have enough resources for a data science team, such platforms can serve well.

However, if you are an enterprise-scale company that needs robust propensity models that are scalable and applicable to your specific business needs, having an experienced data science team will work best. In this way, you can be sure that a created model will be taken care of to adapt to even slight changes in data, and as such provide up-to-date predictions with greater accuracy.
## Reference
The project necessitates the following dependencies: Python 3.x seaborn NumPy Pandas Matplotlib scikit-learn